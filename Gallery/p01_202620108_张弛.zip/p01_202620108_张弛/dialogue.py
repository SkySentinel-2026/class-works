name=input("请问你叫什么名字？")
print("欢迎你,"+name+"!")